# proxy-switch
A simple bash tool to toggle and change system-wide proxy settings
