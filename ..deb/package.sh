#!/bin/bash
parent_path=$( cd "$(dirname "${BASH_SOURCE[0]}")" ; pwd -P )
cd "$parent_path"
# create debian package

mkdir -p ./DEBIAN
mkdir -p ./usr/local/bin
cp ./proxy-switch ./usr/local/bin/
chmod +x ./usr/local/bin/proxy-switch
dpkg-deb --build .
